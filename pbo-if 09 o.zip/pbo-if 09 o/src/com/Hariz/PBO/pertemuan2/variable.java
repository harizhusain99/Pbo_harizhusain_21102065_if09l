package com.Hariz.PBO.pertemuan2;

public class variable {
    public static void main(String[] args) {
        String nama = "Hariz Husain";
        int usia = 22;

        System.out.println("Nama saya adalah " + nama);
        System.out.println("Umur saya adalah " + usia);
    }

}





